import "../styles/GameBoard.css";
import useGameContext from "../hooks/useGameContext.jsx";
import { forwardRef, useEffect, useImperativeHandle, useState } from "react";

const GameBoard = forwardRef(({ setScore, setGameOver, startGame, setCurrentTurn}, ref) => {
  const {
    highlightedSquare,
    moveableSquares,
    hoverSquare,
    visualBoard,
    score,
    turn,
    gameOver,
    promoteBoard,
    resetGame,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
  } = useGameContext();

  useImperativeHandle(ref, () => ({
    resetGame
  }));

  useEffect(() => {
    if(gameOver) {
      setGameOver(gameOver);
    }
  }, [gameOver, setGameOver]);

  useEffect(() => {
    setScore(score);
  }, [score, setScore]);


  useEffect(() => {
    setCurrentTurn(turn);
  }, [turn, setCurrentTurn]);

  return (
    <>
      <div
        draggable="false"
        className={`chessboard ${startGame ? "" : "unclickable"}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        {promoteBoard}
        {highlightedSquare}
        {moveableSquares}
        {hoverSquare}
        {visualBoard}
      </div>
    </>
  );
});

export default GameBoard;